var arr = [1, 2];
console.log(arr, arr.concat(3, 4));
console.log(arr, arr.concat([3, 4]));
console.log(arr, arr.concat([3, [4]]));
