var arr = [1, [[2], 3], 1, 2, 5];
console.log(arr.toString());
