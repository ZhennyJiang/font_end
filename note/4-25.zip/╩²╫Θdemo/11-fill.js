var arr = [1, 2, 3, 4];
console.log(arr, arr.fill(11));
console.log(arr, arr.fill(9, 1, 3));
