var arr = [1, 2, 3, 4, 5];
console.log(arr.indexOf(2));
console.log(arr.lastIndexOf(2));
console.log(arr.indexOf(8));
