var arr = [1, [[2], 3], 1, 2, 5];
console.log(arr.join("-"));

//split
var str = "123";
console.log(str.split("")); //['1','2','3']
