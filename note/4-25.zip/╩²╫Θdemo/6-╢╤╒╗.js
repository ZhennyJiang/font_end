var arr = [1, 2, 3, 4];
console.log(arr, arr.push(8));
console.log(arr, arr.pop());
console.log(arr, arr.unshift(10));
console.log(arr, arr.shift());
